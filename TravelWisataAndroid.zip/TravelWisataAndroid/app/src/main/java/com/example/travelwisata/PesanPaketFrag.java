package com.example.travelwisata;

import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class PesanPaketFrag extends Fragment {

    private EditText editTextNama, editTextEmail, editTextTanggalTrip, editTextJumlahOrang, editTextPilihPaket, editTextUsia;
    private Button buttonSubmit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pesan_paket, container, false);

        // Initialize views
        editTextNama = view.findViewById(R.id.editTextNama);
        editTextEmail = view.findViewById(R.id.editTextEmail);
        editTextTanggalTrip = view.findViewById(R.id.editTextTanggalTrip);
        editTextJumlahOrang = view.findViewById(R.id.editTextJumlahOrang);
        editTextPilihPaket = view.findViewById(R.id.editTextPilihPaket);
        editTextUsia = view.findViewById(R.id.editTextUsia);
        buttonSubmit = view.findViewById(R.id.buttonSubmit);

        // Set button click listener
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get values from EditText
                String nama = editTextNama.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String tanggal_trip = editTextTanggalTrip.getText().toString().trim();
                String jumlah_orang = editTextJumlahOrang.getText().toString().trim();
                String pilih_paket = editTextPilihPaket.getText().toString().trim();
                String usia = editTextUsia.getText().toString().trim();

                // Validate if any field is empty
                if (nama.isEmpty() || email.isEmpty() || tanggal_trip.isEmpty() || jumlah_orang.isEmpty() || pilih_paket.isEmpty() || usia.isEmpty()) {
                    Toast.makeText(getContext(), "Harap isi semua kolom", Toast.LENGTH_SHORT).show();
                } else {
                    // Send data to server
                    new KirimData().execute(nama, email, tanggal_trip, jumlah_orang, pilih_paket, usia);
                }
            }
        });

        return view;
    }

    private class KirimData extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String url = "http://192.168.1.5:8000/tambahpesan";

            // Create JSON object to store data
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("nama", params[0]);
                jsonObject.put("email", params[1]);
                jsonObject.put("tanggal_trip", params[2]);
                jsonObject.put("jumlah_orang", params[3]);
                jsonObject.put("pilih_paket", params[4]);
                jsonObject.put("usia", params[5]);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            // Send data to server
            HttpURLConnection connection = null;
            try {
                URL serverUrl = new URL(url);
                connection = (HttpURLConnection) serverUrl.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");

                OutputStream os = new BufferedOutputStream(connection.getOutputStream());
                os.write(jsonObject.toString().getBytes());
                os.flush();
                os.close();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // If connection is successful
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    // If connection fails
                    return "Error " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // Display message based on server response
            Toast.makeText(getContext(), result, Toast.LENGTH_SHORT).show();
        }
    }
}
